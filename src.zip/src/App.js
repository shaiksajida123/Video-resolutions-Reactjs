import logo from './logo.svg';
import ReactPlayer from 'react-player'
import './App.css';
import React, { Component } from 'react';
import ReactWebMediaPlayer from 'react-web-media-player';

function App() {
  return (
    <div className="App">
    <ReactPlayer url={'https://watch.cloudflarestream.com/fcf971821cfc8c9e790018730590c870'} width="50%" height="50%" controls={true}
     playbackRate={0.5,1,3.85,16} 
     
     onReady={()=> console.log('onReady callback')}
     onStart={()=> console.log('onStart callback')}
     onPause={()=> console.log('onPause callback')}
     onEnded={()=> console.log('onEnded callback')}
     onError={()=> console.log('onError callback')}
      />
       
    </div>
    
  );
}

export default App;
